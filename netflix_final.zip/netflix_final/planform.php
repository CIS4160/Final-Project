<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plans</title>
    <link rel="stylesheet" href="style/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="icon" type="image/png" href="img/fav.png">
</head>
<body>
    <div class="container-fluid">
        <div class="navbar">
            <a href="index_test.php" class="link"><img src="pic/logo.png" alt="back to home page"></a>
        </div>
        <hr>

        <div class="container">
            <div class="step2">
                <p class="uppercase">step 2 of 3</p>
                <h3 class="heading">Choose the plan that's right for you</h3>
                <p class="change">Change or cancel whenever you want.</p>
            </div>

            <div class="packages">
                <div class="offers">
                    <ul class="grey1">
                        <li>Monthly price</li>
                        <li>Video quality</li>
                        <li>Resolution</li>
                        <li>Screens you can watch at the same time.</li>
                        <li>Watch on your TV, computer, mobile phone, and tablet</li>
                        <li>Unlimited movies and TV shows</li>
                        <li>Cancel anytime</li>
                    </ul>
                </div>

                <div class="basic text-center">
                    <div class="box">Basic</div>
                    <ul class="grey">
                        <li>$8.99</li>
                        <li>Good</li>
                        <li>480p</li>
                        <li><span class="smallBox">1</span></li>
                        <li><i class="fas fa-check"></i></li>
                        <li><i class="fas fa-check"></i></li>
                        <li><i class="fas fa-check"></i></li>
                    </ul>
                </div>
                
                <div class="basic text-center">
                    <div class="box">Standard</div>
                    <ul class="grey">
                        <li>$13.99</li>
                        <li>Better</li>
                        <li>1080p</li>
                        <li><span class="smallBox">2</span></li>
                        <li><i class="fas fa-check"></i></li>
                        <li><i class="fas fa-check"></i></li>
                        <li><i class="fas fa-check"></i></li>
                    </ul>
                </div>
                <div class="basic text-center">
                    <div class="box active">Premium<div class="triangle-down"></div></div>
                    
                    <ul class="text-red">
                        <li>$17.99</li>
                        <li>Best</li>
                        <li>4K+HDR</li>
                        <li><span class="smallBox">4</span></li>
                        <li><i class="fas fa-check"></i></li>
                        <li><i class="fas fa-check"></i></li>
                        <li><i class="fas fa-check"></i></li>
                    </ul>
                </div>
            </div>
            <p class="lightGrey">Full HD(1080p), Ultra HD(4K) and HDR availability subject to your internet service and device capabilities. Not all content available in HD, Full HD, Ultra HD or HDR. See <a href="#" class="link blue">Terms of Use</a> for more details.</p>
            <div class="btn-container">
                <a href="payment.php" class="btn red">continue</a>
            </div>
        </div>
    </div>

    <footer class="center">
        <div class="size-90">
          <p class="phonenum">
            Questions? Call <a href="tel:1-844-505-2993">1-844-505-2993</a>
          </p>
  
          <ul class="columns flex-wrap">
            <li class="column is-25">
              <a href="https://help.netflix.com/support/412"><span>FAQ</span></a>
            </li>
            <li class="column is-25">
              <a href="https://help.netflix.com"><span>Help Center</span></a>
            </li>
            <li class="column is-25">
              <a href="https://help.netflix.com/legal/termsofuse"><span>Terms of Use</span></a>
            </li>
            <li class="column is-25">
              <a href="https://help.netflix.com/legal/privacy"><span>Privacy</span></a>
            </li>
            <li class="column is-25">
              <a href="https://help.netflix.com/legal/privacy#cookies"><span>Cookie Preferences</span></a>
            </li>
            <li class="column is-25">
              <a href="https://help.netflix.com/legal/corpinfo"><span>Corporate Information</span></a>
            </li>
          </ul>
  
          <div id="lang-selection">
            <i class="fa fa-globe" aria-hidden="true"></i>
            <select tabindex="0">
              <option value="es">Español</option>
              <option selected value="en">English</option>
            </select>
          </div>
        </div>
    </footer>
</body>
</html>