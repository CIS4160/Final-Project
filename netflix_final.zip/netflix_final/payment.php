<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <link rel="stylesheet" href="style/style1.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link rel="icon" type="image/png" href="img/fav.png">
</head>
<body>
    <div class="container-fluid">
      <div class="navbar">
        <a href="index_test.php" class="link"><img src="pic/logo.png" alt="back to home page"></a>
        <a href="index_test.php" class="link">Sign Out</a>
    </div>

        <div class="container">
            <div class="step2">
                <div class="icon text-center"><i class="fas fa-lock"></i></div>
                <div class="p1">
                    <p class="uppercase text-center">step 3 of 3</p>
                    <h2 class="heading text-center">Set up your payment</h2>    
                </div>
                <p class="text1 text-center">Your membership starts as <br>soon as you set up payment.</p><br>
                <b><h3 class="text2 text-center">No commitments. <br>Cancel online anytime.</h3></b>
            </div>
            
            <form action="">
                <p class="text5 text-right">Secure Server<i class="fas fa-lock red"></i></p>
               
            <!--This is updated -->
            <a href="creditoption.php" class="transfer_link">
               <div class="parent">
                    <input type="text" placeholder="Credit or Debit Card">
                    <img class='logos logos1' src="pic/visa.png" alt="">
                    <img class='logos logos2' src="pic/mastercard.jpg" alt="">
                    <img class='logos logos3' src="pic/ae.png" alt="">
                    <img class='logos logos4' src="pic/discover.png" alt="">
                    <i class="right-arr fas fa-chevron-right"></i>
                </div>
            </a>

            <a href="creditoption.php" class="transfer_link">
                <div class="parent">
                    <input type="text" placeholder="PayPal">
                    <img class='logos logos5' src="pic/paypal.jpg" alt="">
                    <i class="right-arr fas fa-chevron-right"></i>   
                </div>
            </a>

            <a href="creditoption.php" class="transfer_link">
                <div class="parent">
                    <input type="text" placeholder="Gift Code">
                    <img class='logos logos6' src="pic/logo.png" alt="">
                    <i class="right-arr fas fa-chevron-right"></i>
                </div>
            </a>
            </form>
        </div>
    </div>


    <footer class="center">
        <div class="size-90">
          <p class="phonenum">
            Questions? Call <a href="tel:1-844-505-2993">1-844-505-2993</a>
          </p>
  
          <ul class="columns flex-wrap">
            <li class="column is-25">
              <a href="https://help.netflix.com/support/412"><span>FAQ</span></a>
            </li>
            <li class="column is-25">
              <a href="https://help.netflix.com"><span>Help Center</span></a>
            </li>
            <li class="column is-25">
              <a href="https://help.netflix.com/legal/termsofuse"><span>Terms of Use</span></a>
            </li>
            <li class="column is-25">
              <a href="https://help.netflix.com/legal/privacy"><span>Privacy</span></a>
            </li>
            <li class="column is-25">
              <a href="https://help.netflix.com/legal/privacy#cookies"><span>Cookie Preferences</span></a>
            </li>
            <li class="column is-25">
              <a href="https://help.netflix.com/legal/corpinfo"><span>Corporate Information</span></a>
            </li>
          </ul>
  
          <div id="lang-selection">
            <i class="fa fa-globe" aria-hidden="true"></i>
            <select tabindex="0">
              <option value="es">Español</option>
              <option selected value="en">English</option>
            </select>
          </div>
        </div>
      </footer>
</body>
</html>