<?php
session_start(); 

  if (!isset($_SESSION['email'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NETFLIX HOME</title>
    <link rel="stylesheet" type="text/css" href="css/home.css">
    <link rel="icon" type="image/png" href="img/fav.png">
</head>
<body>
    <div class="home_image"></div>
</body>
</html>