<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Netflix</title>

    <link href="css/style_test.css" rel="stylesheet"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <link rel="icon" type="image/png" href="img/fav.png">

    <!--button to display the frequently asked questions-->
    <script>
      function setVisibility (button) {
        var x = button.id;
        var para1 = document.getElementById("para_1");
        var para2 = document.getElementById("para_2");
        var para3 = document.getElementById("para_3");
        var para4 = document.getElementById("para_4");
        var para5 = document.getElementById("para_5");

        switch (x) {
          case '1':
            para1.style.display = para1.style.display === 'none' ? '' : 'none';
            break;

          case '2':
            para2.style.display = para2.style.display === 'none' ? '' : 'none';
            break;

          case '3':
            para3.style.display = para3.style.display === 'none' ? '' : 'none';
            break;

          case '4':
            para4.style.display = para4.style.display === 'none' ? '' : 'none';
            break;

          case '5':
            para5.style.display = para5.style.display === 'none' ? '' : 'none';
            break;

          default:
            return false;
        }

      }

    </script>

  </head>

  <body>
    <header>
      <nav>
        <a href="index_test.php" class="logo">
          <img src="img/logo.svg">
        </a>
        <a class="signin" href="login.php">
          Sign In
        </a>
      </nav>

      <section class="pitch">
        <h1 class="pitch__title">Unlimited movies, TV shows, and more.</h1>
        <p class="pitch__subtitle">Watch anywhere. Cancel anytime.</p>
        <p class="pitch__paragraph">Ready to watch? Enter your email to create or restart your membership.</p>
  
        <div class="input-group mb-3">
          <input type="text" class="home_email_input" placeholder="Email address" aria-label="Email address" aria-describedby="basic-addon2">
          <div class="input-group-append">
            <button class="home_email_button" type="button">
              <a href="registar1.php" class="transfer_link">GET STARTED ></a>
            </button>
          </div>
        </div>
  
      </section>
    </header>

    <!---Main Content-->
    <div class="row home_block">
      <div class="col">
        <div class="row home_block_content">
          <div class="col block">
            <h1 class="block_title">Enjoy on your TV.</h1>
            <p class="block__subtitle">Watch on Smart TVs, Playstation, Xbox, Chromecast, Apple TV, Blu-ray players, and more.</p>
          </div>
  
          <div class="col">
            <img src="img/home-img3.png" alt="image display" class="image1">
          </div>
        </div>
  
        <div class="row home_block_content">
          <div class="col">
            <img src="img/home-img2.png" alt="image display" class="image1">
          </div>

          <div class="col">
            <h1 class="block_title">Download your shows to watch offline.</h1>
            <p class="block__subtitle">Save your favorites easily and always have something to watch.</p>
          </div>
        </div>
  
        <div class="row home_block_content">
          <div class="col block">
            <h1 class="block_title">Watch everywhere.</h1>
            <p class="block__subtitle">Stream unlimited movies and TV shows on your phone, tablet, laptop, and TV without paying more.</p>
          </div>
  
          <div class="col">
            <img src="img/home-img1.png" alt="image display" class="image1">
          </div>
        </div>
  
        <div class="row home_block_content">
          <div class="col asked_question_block">
            <h1 class="question_title">Frequently Asked Questions</h1>

            <div class="row">
              <input class="question_button" type="button" name="type" id='1' value='What is Netflix?' onclick="setVisibility(this)">
              <p class="question_answer" id="para_1" style="display:none">Netflix is a streaming service that offers a wide variety 
              of award-winning TV shows, movies, anime, documentaries, 
              and more on thousands of internet-connected devices.<br><br>
              You can watch as much as you want, whenever you want without a single commercial
               – all for one low monthly price. There's always something new to discover and 
               new TV shows and movies are added every week!</p>
            </div>

            <div class="row">
              <input class="question_button" type="button" name="type" id='2' value='How much does Netflix cost?' onclick="setVisibility(this)">
              <p class="question_answer" id="para_2" style="display:none"> Watch Netflix on your smartphone, 
                tablet, Smart TV, laptop, or streaming device, all for one fixed monthly fee. 
                Plans range from $8.99 to $17.99 a month. No extra costs, no contracts.</p>
            </div>

            <div class="row">
              <input class="question_button" type="button" name="type" id='3' value='Where can I watch?' onclick="setVisibility(this)">
              <p class="question_answer" id="para_3" style="display:none">Watch anywhere, anytime, on an unlimited number of devices.
                 Sign in with your Netflix account to watch instantly on the web at netflix.com 
                 from your personal computer or on any internet-connected device that offers the Netflix 
                 app, including smart TVs, smartphones, tablets, streaming media players and game consoles.<br><br>
                 You can also download your favorite shows with the iOS, Android, or Windows 10 app. 
                 Use downloads to watch while you're on the go and without an internet connection. 
                 Take Netflix with you anywhere.</p>
            </div>

            <div class="row">
              <input class="question_button" type="button" name="type" id='4' value='How do I cancel?' onclick="setVisibility(this)">
              <p class="question_answer" id="para_4" style="display:none">Netflix is flexible. 
                There are no pesky contracts and no commitments. 
                You can easily cancel your account online in two clicks. 
                There are no cancellation fees – start or stop your account anytime.</p>
            </div>

            <div class="row">
              <input class="question_button" type="button" name="type" id='5' value='What can I watch on Netflix?' onclick="setVisibility(this)">
              <p class="question_answer" id="para_5" style="display:none">Netflix has an extensive library of 
                feature films, documentaries, TV shows, anime, award-winning Netflix originals,
                 and more. Watch as much as you want, anytime you want.</p>
            </div>

            <div class="question_section">
              <p class="pitch__paragraph">Ready to watch? Enter your email to create or restart your membership.</p>
              <div class="input-group mb-3">
                <input type="text" class="home_email_input" placeholder="Email address" aria-label="Email address" aria-describedby="basic-addon2">
                <div class="input-group-append">
                  <button class="home_email_button" type="button">
                    <a href="registar1.php" class="transfer_link">GET STARTED ></a>
                  </button>
                </div>
              </div>
            </div>

            
          </div>
        </div>

    


    <!-- <div id="features">
      <nav>
        <div class="center columns size-80">
          <a class="column is-selected" href="#" data-id="cancelanytime">
            <img alt="Cancel anytime" src="img/cancel.svg"/>
            <h2>
              No commitments
              <br/>
              Cancel online at anytime
            </h2>
          </a>

          <a class="column" href="#" data-id="watchanywhere">
            <img alt="Watch anywhere" src="img/watchanywhere.svg"/>
            <h2>
              Watch anywhere
            </h2>
          </a>

          <a class="column" href="#" data-id="pickprice">
            <img alt="Pick your price" src="img/pickprice.svg"/>
            <h2>
              Pick your price
            </h2>
          </a>
        </div>
      </nav>

      <article>
        <section class="is-selected center size-70" data-id="cancelanytime">
          <div class="columns">
            <div class="column">
              <h2>
                If you decide Netflix isn't for you - no problem. No commitment. Cancel online anytime.
              </h2>
              <button class="btn btn-large">JOIN FOR A FREE MONTH</button>
            </div>

            <div class="column">
              <img src="img/cancelanytime_withdevice.png"/>
            </div>
          </div>
        </section>

        <section class="center size-80" id="watchanywhere" data-id="watchanywhere">
          <div class="columns">
            <h2 class="column">
              Watch TV shows and movies anytime, anywhere — personalized for you.
            </h2>
            <button class="btn btn-large column is-narrow">JOIN FOR A FREE MONTH</button>
          </div>

          <div class="columns size-90 center">
            <div class="column text-center">
              <img src="img/asset_TV_UI.png"/>
              <h3>Watch on your TV</h3>
              <p>Smart TVs, PlayStation, Xbox, Chromecast, Apple TV, Blu-ray players and more.</p>
            </div>

            <div class="column text-center">
              <img src="img/asset_mobile_tablet_UI_2.png"/>
              <h3>Watch instantly or download for later</h3>
              <p>Available on phone and tablet, wherever you go.</p>
            </div>

            <div class="column text-center">
              <img src="img/asset_website_UI.png"/>
              <h3>Use any computer</h3>
              <p>Watch right on Netflix.com.</p>
            </div>
          </div>
        </section>

        <section class="center size-70" id="pickprice" data-id="pickprice">
          <div class="text-center">
            <h2>
              Choose one plan and watch everything on Netflix.
            </h2>
            <button class="btn btn-large">JOIN FOR A FREE MONTH</button>
          </div>

          <table>
            <thead>
              <tr>
                <th></th>
                <th>Basic</th>
                <th>Standard</th>
                <th>Premium</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Monthly price after free month ends on 6/27/17</td>
                <td>$8.99</td>
                <td>$13.99</td>
                <td>$17.99</td>
              </tr>
              <tr>
                <td>HD available</td>
                <td><i class="fa fa-times"></i></td>
                <td><i class="fa fa-check"></i></td>
                <td><i class="fa fa-check"></i></td>
              </tr>
              <tr>
                <td>Ultra HD available</td>
                <td><i class="fa fa-times"></i></td>
                <td><i class="fa fa-times"></i></td>
                <td><i class="fa fa-check"></i></td>
              </tr>
              <tr>
                <td>Screens you can watch on at the same time</td>
                <td>1</td>
                <td>2</td>
                <td>4</td>
              </tr>
              <tr>
                <td>Watch on your laptop, TV, phone and tablet</td>
                <td><i class="fa fa-check"></i></td>
                <td><i class="fa fa-check"></i></td>
                <td><i class="fa fa-check"></i></td>
              </tr>
              <tr>
                <td>Unlimited movies and TV shows</td>
                <td><i class="fa fa-check"></i></td>
                <td><i class="fa fa-check"></i></td>
                <td><i class="fa fa-check"></i></td>
              </tr>
              <tr>
                <td>Cancel anytime</td>
                <td><i class="fa fa-check"></i></td>
                <td><i class="fa fa-check"></i></td>
                <td><i class="fa fa-check"></i></td>
              </tr>
              <tr>
                <td>First month free</td>
                <td><i class="fa fa-check"></i></td>
                <td><i class="fa fa-check"></i></td>
                <td><i class="fa fa-check"></i></td>
              </tr>
            </tbody>
          </table>
        </section>
      </article>
    </div> -->

    <footer class="center">
      <div class="size-90">
        <p>
          Questions? Call <a href="tel:1-844-505-2993">1-844-505-2993</a>
        </p>

        <ul class="columns flex-wrap">
          <li class="column is-25">
            <a href="https://help.netflix.com/support/412"><span>FAQ</span></a>
          </li>
          <li class="column is-25">
            <a href="https://help.netflix.com"><span>Help Center</span></a>
          </li>
          <li class="column is-25">
            <a href="https://www.netflix.com/yourAccount"><span>Account</span></a>
          </li>
          <li class="column is-25">
            <a href="https://media.netflix.com/"><span>Media Center</span></a>
          </li>
          <li class="column is-25">
            <a href="http://ir.netflix.com/"><span>Investor Relations</span></a>
          </li>
          <li class="column is-25">
            <a href="https://jobs.netflix.com/jobs"><span>Jobs</span></a>
          </li>
          <li class="column is-25">
            <a href="https://www.netflix.com/redeem"><span>Redeem Gift Cards</span></a>
          </li>
          <li class="column is-25">
            <a href="https://www.netflix.com/gift-cards"><span>Buy Gift Cards</span></a>
          </li>
          <li class="column is-25">
            <a href="https://www.netflix.com/watch"><span>Ways to Watch</span></a>
          </li>
          <li class="column is-25">
            <a href="https://help.netflix.com/legal/termsofuse"><span>Terms of Use</span></a>
          </li>
          <li class="column is-25">
            <a href="https://help.netflix.com/legal/privacy"><span>Privacy</span></a>
          </li>
          <li class="column is-25">
            <a href="https://help.netflix.com/legal/privacy#cookies"><span>Cookie Preferences</span></a>
          </li>
          <li class="column is-25">
            <a href="https://help.netflix.com/legal/corpinfo"><span>Corporate Information</span></a>
          </li>
          <li class="column is-25">
            <a href="https://help.netflix.com/en/contactus"><span>Contact Us</span></a>
          </li>
          <li class="column is-25">
            <a href="https://fast.com"><span>Speed Test</span></a>
          </li>
          <li class="column is-25">
            <a href="https://help.netflix.com/legal/notices"><span>Legal Notices</span></a>
          </li>
          <li class="column is-25">
            <a href="https://www.netflix.com/es-en/originals"><span>Netflix Originals</span></a>
          </li>
        </ul>

        <div id="lang-selection">
          <i class="fa fa-globe" aria-hidden="true"></i>
          <select tabindex="0">
            <option value="es">Español</option>
            <option selected value="en">English</option>
          </select>
        </div>
      </div>
    </footer>
  </div>
</div>   

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="js/app.js"></script>
  </body>
</html>
