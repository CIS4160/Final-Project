<?php include('server.php') ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Sign in</title>
    <link href="css/login.css" rel="stylesheet"/>
    <link rel="icon" type="image/png" href="img/fav.png">
  </head>

<body>
    <div class="wrapper">
        <div class="header">
            <div class="logo">
                <a href="index_test.php"><img src="img/logo.png" alt="logo"></a>
            </div>
        </div>

        <div class="login__body">
            <div class="login__box">
                <h2>Sign in</h2>
                <form action="login.php" method="POST">
                <?php include('errors.php'); ?>
                    <div class="input__wrap">
                        <input type="email" placeholder= "Email or phone number" name="email">
                    </div>
                    <div class="input__wrap">
                        <input type="password" placeholder= "Password" name="password">
                    </div>
                    <div class="input__wrap">
                        <button type="submit" name="login_user"> Sign in</button>
                    </div>

                    <div class="support">
                        <div class="remember">
                            <span> <input type="checkbox" style="margin: 0; padding: 0; height:13px;"></span>
                            <span>Remember me</span>
                        </div>
                        
                        <div class="need__help">
                        Need help?
                        </div>
                        
                    </div>
                    <div class="login__footer">
                        <div class="login__facebook">
                            <span> <img src="https://assets.nflxext.com/ffe/siteui/login/images/FB-f-Logo__blue_57.png" alt="facebook icon"></span>
                            <span><a href="#" style="text-decoration: none; color: #737373; font-size:13px;">Login with Facebook</a></span>
                        </div>
                        <div class="sign__up">
                            <p>New to Netflix? <a href="registar1.php">Sign up now.</a></p>
                        </div>

                        <div class="terms">
                            <p>This page is protected by Google reCAPTCHA to ensure you're not a bot. <a href="#">Learn More.</a></p>
                        </div>
                    
                    </div>
                </form>
            </div>
        </div>
    </div>
 
</body>
</html>